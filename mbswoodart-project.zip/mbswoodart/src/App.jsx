import { useState } from "react";
import { WOODS } from "./data/woods";
import Nav from "./components/Nav";
import Hero from "./components/Hero";
import WoodRail from "./components/WoodRail";
import ProductGrid from "./components/ProductGrid";
import Process from "./components/Process";
import Footer from "./components/Footer";

const ETSY_URL = "https://www.etsy.com/shop/MbsWoodArt";

export default function App() {
  const [active, setActive] = useState(WOODS[0]);

  return (
    <div
      style={{ "--accent": active.hex, "--grain": active.grain }}
      className="min-h-screen bg-[#F1E8DC] text-[#241F1C] transition-colors duration-500"
    >
      <Nav etsyUrl={ETSY_URL} />
      <Hero active={active} />
      <WoodRail active={active} onSelect={setActive} />
      <ProductGrid />
      <Process />
      <Footer etsyUrl={ETSY_URL} />
    </div>
  );
}
