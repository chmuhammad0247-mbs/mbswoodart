export default function Footer({ etsyUrl }) {
  return (
    <footer className="px-6 md:px-12 py-10 flex flex-col md:flex-row justify-between gap-4 items-start md:items-center">
      <span className="display-font font-semibold">MbsWoodArt</span>
      <p className="text-sm text-[#4A3B30]">Handmade in small batches · Ships worldwide</p>
      <a
        href={etsyUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="cta mono-font text-xs px-4 py-2 rounded-full"
        style={{ background: "var(--accent)", color: "#F1E8DC" }}
      >
        VISIT ETSY SHOP
      </a>
    </footer>
  );
}
