export default function GrainSwatch({ hex, grain, className = "", children }) {
  return (
    <div
      className={className}
      style={{
        background: `repeating-linear-gradient(100deg, ${hex} 0px, ${hex} 2px, ${grain} 3px, ${grain} 4px, ${hex} 6px)`,
      }}
    >
      {children}
    </div>
  );
}
