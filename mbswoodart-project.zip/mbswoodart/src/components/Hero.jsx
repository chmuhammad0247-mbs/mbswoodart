import GrainSwatch from "./GrainSwatch";

export default function Hero({ active }) {
  return (
    <section className="px-6 md:px-12 pt-8 pb-16 grid md:grid-cols-2 gap-10 items-center">
      <div>
        <h1 className="display-font text-4xl md:text-6xl leading-[1.05] font-semibold">
          Handcrafted,
          <br />
          <span className="accent-underline underline">one grain</span> at a time.
        </h1>
        <p className="mt-6 text-base md:text-lg max-w-md text-[#4A3B30]">
          Small-batch wooden goods, cut, turned, and finished by hand in a one-person
          workshop. No two boards are identical — that's the point.
        </p>
        <div className="mt-8 flex gap-4 flex-wrap">
          <a
            href="#shop"
            className="cta rounded-full px-6 py-3 font-medium text-sm"
            style={{ background: "var(--accent)", color: "#F1E8DC" }}
          >
            Browse the shop
          </a>
          <a href="#process" className="cta rounded-full px-6 py-3 font-medium text-sm border-2 border-[#241F1C]">
            See how it's made
          </a>
        </div>
      </div>

      <GrainSwatch
        hex={active.hex}
        grain={active.grain}
        className="h-64 md:h-96 rounded-2xl relative overflow-hidden"
      >
        <div className="absolute bottom-4 left-4 mono-font text-xs bg-[#241F1C] text-[#F1E8DC] px-3 py-1 rounded-full">
          {active.name} grain, actual tone
        </div>
      </GrainSwatch>
    </section>
  );
}
