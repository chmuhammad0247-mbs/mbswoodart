export default function Nav({ etsyUrl }) {
  return (
    <header className="flex items-center justify-between px-6 md:px-12 py-6">
      <span className="display-font text-xl md:text-2xl font-semibold tracking-tight">MbsWoodArt</span>
      <a
        href={etsyUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="cta mono-font text-xs md:text-sm px-4 py-2 rounded-full border-2"
        style={{ borderColor: "var(--accent)", color: "#241F1C" }}
      >
        SHOP ON ETSY
      </a>
    </header>
  );
}
