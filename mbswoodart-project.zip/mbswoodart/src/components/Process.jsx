import { STEPS } from "../data/products";

export default function Process() {
  return (
    <section id="process" className="px-6 md:px-12 py-16 bg-[#241F1C] text-[#F1E8DC]">
      <h2 className="display-font text-3xl md:text-4xl font-semibold mb-10">Three steps, every piece</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {STEPS.map((s) => (
          <div key={s.n}>
            <span className="mono-font text-sm" style={{ color: "var(--accent)" }}>
              Step {s.n}
            </span>
            <h3 className="display-font text-xl font-semibold mt-2 mb-2">{s.title}</h3>
            <p className="text-sm text-[#F1E8DC]/80">{s.body}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
