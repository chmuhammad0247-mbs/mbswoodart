import GrainSwatch from "./GrainSwatch";
import { WOODS } from "../data/woods";

export default function ProductCard({ product }) {
  const w = WOODS.find((x) => x.id === product.wood);

  return (
    <a
      href={product.etsyUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="card-link rounded-xl overflow-hidden border-2 border-transparent hover:border-[#241F1C]/20 bg-white/40 block"
    >
      {product.image ? (
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          width={400}
          height={144}
          className="h-36 w-full object-cover"
        />
      ) : (
        <GrainSwatch hex={w.hex} grain={w.grain} className="h-36" />
      )}
      <div className="p-5">
        <div className="flex justify-between items-baseline mb-1">
          <h3 className="font-semibold">{product.name}</h3>
          <span className="mono-font text-sm">{product.price}</span>
        </div>
        <p className="text-sm text-[#4A3B30] mb-2">{product.desc}</p>
        <span className="mono-font text-[11px] uppercase tracking-wide" style={{ color: w.hex }}>
          {w.name}
        </span>
      </div>
    </a>
  );
}
