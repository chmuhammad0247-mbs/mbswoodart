import ProductCard from "./ProductCard";
import { PRODUCTS } from "../data/products";

export default function ProductGrid() {
  return (
    <section id="shop" className="px-6 md:px-12 py-16">
      <h2 className="display-font text-3xl md:text-4xl font-semibold mb-2">From the workshop</h2>
      <p className="text-[#4A3B30] mb-10">Every piece ships oiled, sanded, and ready to use.</p>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {PRODUCTS.map((p) => (
          <ProductCard key={p.name} product={p} />
        ))}
      </div>
    </section>
  );
}
