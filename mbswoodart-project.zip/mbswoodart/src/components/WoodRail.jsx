import { WOODS } from "../data/woods";

export default function WoodRail({ active, onSelect }) {
  return (
    <section className="px-6 md:px-12 py-10 border-y-2 border-[#241F1C]/10">
      <p className="mono-font text-xs uppercase tracking-widest text-[#4A3B30] mb-4">
        Pick a species — the shop changes tone with it
      </p>
      <div className="flex gap-4 flex-wrap">
        {WOODS.map((w) => (
          <button
            key={w.id}
            onClick={() => onSelect(w)}
            className="wood-btn flex flex-col items-start rounded-xl overflow-hidden border-2 w-[9.5rem]"
            style={{ borderColor: active.id === w.id ? w.hex : "transparent" }}
            aria-pressed={active.id === w.id}
          >
            <span
              className="h-16 w-full block"
              style={{
                background: `repeating-linear-gradient(95deg, ${w.hex} 0px, ${w.hex} 3px, ${w.grain} 4px, ${w.grain} 5px, ${w.hex} 8px)`,
              }}
            />
            <span className="px-3 py-2 text-left bg-white/40 w-full">
              <span className="block font-semibold text-sm">{w.name}</span>
              <span className="block text-[11px] text-[#4A3B30] leading-tight">{w.note}</span>
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
