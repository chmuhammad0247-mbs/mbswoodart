// Edit this list to update the shop — no other file needs to change.
// image: put files in /public/products/ and reference them as "/products/filename.jpg"
export const PRODUCTS = [
  { name: "Live-Edge Serving Board", wood: "walnut", price: "$48", desc: "One-of-a-kind slab with bark-edge detail, oiled to a satin sheen.", image: null, etsyUrl: "https://www.etsy.com/shop/MbsWoodArt" },
  { name: "Stacking Trinket Box", wood: "oak", price: "$32", desc: "Hand-cut joints, felt-lined base, brass hinge.", image: null, etsyUrl: "https://www.etsy.com/shop/MbsWoodArt" },
  { name: "Turned Bud Vase", wood: "cherry", price: "$26", desc: "Lathe-turned from a single reclaimed cherry limb.", image: null, etsyUrl: "https://www.etsy.com/shop/MbsWoodArt" },
  { name: "Desk Pen Tray", wood: "maple", price: "$22", desc: "Minimal tray with a sanded finger-groove for pens.", image: null, etsyUrl: "https://www.etsy.com/shop/MbsWoodArt" },
  { name: "Cedar Coaster Set (4)", wood: "cedar", price: "$18", desc: "Naturally water-resistant, felt feet included.", image: null, etsyUrl: "https://www.etsy.com/shop/MbsWoodArt" },
  { name: "Carved Bookend Pair", wood: "walnut", price: "$40", desc: "Weighted base, hand-carved curve, wax finish.", image: null, etsyUrl: "https://www.etsy.com/shop/MbsWoodArt" },
];

export const STEPS = [
  { n: 1, title: "Select the timber", body: "Every board is checked by hand for grain direction, moisture, and character before it earns a place in the shop." },
  { n: 2, title: "Shape & sand", body: "Rough-cut on the bandsaw, then worked through six grits until the surface feels like glass." },
  { n: 3, title: "Oil & finish", body: "Food-safe oil is hand-rubbed in three coats, letting the grain darken and come alive." },
];
