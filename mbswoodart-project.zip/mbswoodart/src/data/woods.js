export const WOODS = [
  { id: "walnut", name: "Walnut", hex: "#5C3A26", grain: "#3F2818", note: "Deep, chocolate-brown grain" },
  { id: "oak", name: "Oak", hex: "#C89B6E", grain: "#9C7346", note: "Warm gold with bold rays" },
  { id: "maple", name: "Maple", hex: "#DCC79A", grain: "#B79A67", note: "Pale, tight, quiet grain" },
  { id: "cherry", name: "Cherry", hex: "#8B3A2B", grain: "#5E2419", note: "Reddens beautifully with age" },
  { id: "cedar", name: "Cedar", hex: "#A9713F", grain: "#7A4E28", note: "Fragrant, soft, honey tone" },
];
